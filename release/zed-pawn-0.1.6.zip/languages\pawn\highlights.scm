; Pawn uses the same capture vocabulary as Zed's C/C++ grammar.
; Colors are provided by the active Zed theme.

(identifier) @variable

((identifier) @constant
  (#match? @constant "^([A-Z][A-Z\\d_]*|INVALID_[A-Za-z0-9_]*)$"))

"break" @keyword
"case" @keyword
"const" @keyword
"continue" @keyword
"default" @keyword
"do" @keyword
"else" @keyword
"enum" @keyword
"extern" @keyword
"for" @keyword
"if" @keyword
"inline" @keyword
"return" @keyword
"sizeof" @keyword
"static" @keyword
"struct" @keyword
"switch" @keyword
"typedef" @keyword
"union" @keyword
"volatile" @keyword
"while" @keyword

; Pawn declaration/control keywords are identifiers in the C grammar.
((identifier) @keyword
  (#match? @keyword "^(new|stock|public|native|forward|hook|task|ptask|function|func|state|assert|goto|exit|sleep|foreach|tagof|char|void)$"))

; Preprocessor directives use the C/C++ keyword capture vocabulary.
"#define" @keyword
"#elif" @keyword
"#else" @keyword
"#endif" @keyword
"#if" @keyword
"#ifdef" @keyword
"#ifndef" @keyword
"#include" @keyword
(preproc_directive) @keyword

"--" @operator
"-" @operator
"-=" @operator
"->" @operator
"=" @operator
"!=" @operator
"*" @operator
"&" @operator
"&&" @operator
"+" @operator
"++" @operator
"+=" @operator
"<" @operator
"==" @operator
">" @operator
">=" @operator
"<=" @operator
"||" @operator
"/" @operator
"%" @operator
"!" @operator
"|" @operator
"^" @operator
"~" @operator

"." @delimiter
";" @delimiter

(string_literal) @string
(system_lib_string) @string
(null) @constant
(number_literal) @number
(char_literal) @number

(field_identifier) @property
(statement_identifier) @label
(type_identifier) @type
(primitive_type) @type
(sized_type_specifier) @type

; Pawn tags and common built-in types use the theme's type color.
((identifier) @type
  (#match? @type "^(Float|bool|Tag|Text|Menu|PlayerText|Text3D|DB|DBResult|File|Key|FileType|String)$"))

(call_expression
  function: (identifier) @function)
(call_expression
  function: (field_expression
    field: (field_identifier) @function))
(function_declarator
  declarator: (identifier) @function)
(preproc_function_def
  name: (identifier) @function)

(comment) @comment
